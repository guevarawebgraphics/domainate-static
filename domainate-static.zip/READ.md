## Static Template for Custom Web Designing

# 1. Use `npm install` to install node on this source code

# 2. run `npm run sass-watch` to automatically compile your sass files into single css file
